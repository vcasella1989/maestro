#bin/bash

apt-get update
mkdir /opt/maestro
tar -x maestro.tar --directory /opt/maestro

export DEBIAN_FRONTEND=noninteractive
cd /opt/maestro/bin
./maestro